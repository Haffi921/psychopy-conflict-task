from ._base_component import BaseComponent


class AudioComponent(BaseComponent):
    pass
