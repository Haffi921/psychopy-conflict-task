# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['conflict_task',
 'conflict_task.component',
 'conflict_task.devices',
 'conflict_task.sequence',
 'conflict_task.util',
 'sequencing_helpers']

package_data = \
{'': ['*']}

install_requires = \
['PsychoPy>=2021.2.3,<2022.0.0']

setup_kwargs = {
    'name': 'conflict-task',
    'version': '1.3.0',
    'description': '',
    'long_description': None,
    'author': 'Hafsteinn Ragnarsson',
    'author_email': 'haffi921@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.8.10',
}


setup(**setup_kwargs)
